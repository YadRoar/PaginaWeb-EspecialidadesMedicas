document.addEventListener("DOMContentLoaded", function() {
    console.log("Documento cargado");

    // Mostrar el formulario cuando se hace clic en el botón "Agendar"
    document.getElementById('agendar-btn').addEventListener('click', function() {
        console.log("Botón Agendar clickeado");
        document.getElementById('agendar-cita-form').style.display = 'block';
    });

    // Ocultar el formulario cuando se hace clic en el botón de cerrar
    document.querySelector('.close').addEventListener('click', function() {
        console.log("Botón Cerrar clickeado");
        document.getElementById('agendar-cita-form').style.display = 'none';
    });

    // Manejar el envío del formulario
    document.getElementById('agendar-form').addEventListener('submit', function(event) {
        event.preventDefault();

        // Guardar los valores del formulario
        const nombre = document.getElementById('nombre').value;
        const cedula = document.getElementById('cedula').value;
        const telefono = document.getElementById('telefono').value;
        const email = document.getElementById('email').value;
        const especialidad = document.getElementById('especialidad').value;
        const fecha = document.getElementById('fecha').value;
        const hora = document.getElementById('hora').value;
        const motivo = document.getElementById('motivo').value;

        // Crear un objeto con los datos del formulario
        const formData = {
            nombre,
            cedula,
            telefono,
            email,
            especialidad,
            fecha,
            hora,
            motivo
        };

        // Mostrar los datos en la consola
        console.log("Datos del formulario:", formData);

        // Aquí se realizan otras acciones con los datos del formulario, como enviarlos a un servidor

        // Ocultar el formulario después de enviar los datos
        document.getElementById('agendar-cita-form').style.display = 'none';
    });

    // Función para generar las opciones de hora disponibles
    function generarHorasDisponibles() {
        const selectHora = document.getElementById('hora');
        selectHora.innerHTML = '';

        const horaInicio = 8;
        const minutoInicio = 30;
        const horaFin = 18;
        const minutoFin = 30;
        const intervaloMinutos = 30;

        for (let hora = horaInicio; hora <= horaFin; hora++) {
            for (let minuto = (hora === horaInicio ? minutoInicio : 0); minuto < 60; minuto += intervaloMinutos) {
                if (hora === horaFin && minuto > minutoFin) {
                    break;
                }
                const horaStr = `${hora.toString().padStart(2, '0')}:${minuto.toString().padStart(2, '0')}`;
                const option = document.createElement('option');
                option.value = horaStr;
                option.textContent = horaStr;
                selectHora.appendChild(option);
            }
        }
    }

    // Llamar a la función para generar las opciones de hora disponibles al cargar la página
    generarHorasDisponibles();
});
