document.addEventListener('DOMContentLoaded', function() {
    const navLinks = document.querySelectorAll('.nav-link');
    const sections = document.querySelectorAll('.content-section');

    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();

            // Remove active class from all nav-links
            navLinks.forEach(link => link.classList.remove('active'));

            // Hide all sections
            sections.forEach(section => section.style.display = 'none');

            // Show the selected section
            const sectionId = this.getAttribute('href').substring(1); // Remove the #
            document.getElementById(sectionId).style.display = 'block';

            // Add active class to the clicked nav-link
            this.classList.add('active');
        });
    });
});

// Redirige a la página de inicio cuando se haga clic en el botón de salir
document.getElementById("logoutButton").onclick = function() {
    window.location.href = './public/BienestarTotal.html'; 
}
