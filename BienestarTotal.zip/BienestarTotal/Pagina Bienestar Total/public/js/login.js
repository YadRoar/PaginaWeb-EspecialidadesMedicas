const $submit = document.getElementById('submit'),
      $password = document.getElementById('password'),
      $username = document.getElementById('username'),
      $visible = document.getElementById('visible');

// Lista de usuarios permitidos
const validUsers = ["kev", "vale", "yadi", "cisco"];
const validPassword = "12345";

// Mostrar u ocultar la contraseña
document.addEventListener("change", (e) => {
    if (e.target === $visible) {
        $password.type = $visible.checked ? "text" : "password";
    }
});

// Validación del usuario y contraseña 
document.addEventListener("click", (e) => {
    if (e.target === $submit) {
        e.preventDefault();  // Previene el comportamiento predeterminado del formulario.

        // Verifica si el usuario está en la lista de usuarios permitidos y si la contraseña es válida
        if (validUsers.includes($username.value) && $password.value === validPassword) {
            window.location.href = "dash.html";  // Redirigir si es válido
        } else {
            alert("Usuario o contraseña incorrectos. Intente de nuevo.");
        }
    }
});