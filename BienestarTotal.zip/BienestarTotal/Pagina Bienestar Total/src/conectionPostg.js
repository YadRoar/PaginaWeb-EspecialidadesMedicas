import pg from "pg";



// Llamar a la base de datos
const pool = new pg.Pool({
    host: 'localhost',
    port: 5432,
    database: 'bienestar',
    user: 'postgres',
    password: '1234'
 });