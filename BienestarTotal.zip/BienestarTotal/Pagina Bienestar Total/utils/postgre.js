import {pool} from "./database/conectionPostg.js";

const getDoctors = async () => {
    try {
        const result = await pool.query("SELECT * FROM doctores");
    } catch (error) {
        console.error(error);
    }
    
};

getDoctors();
