
const express = require('express');
const path = require('path');
const app = express();
const port = 8085;

app.use(express.urlencoded({ extended: true }));

// Configura el directorio estático
app.use(express.static(path.join(__dirname, 'public')));

// Ruta para manejar todas las demás solicitudes y enviar el archivo BienestarTotal.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'BienestarTotal.html'));
});

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});

