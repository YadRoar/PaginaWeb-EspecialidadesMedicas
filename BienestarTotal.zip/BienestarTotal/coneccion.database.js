const { Client } = require('pg');
const options = {
    user: 'postgres',
    host: 'localhost',
    database: 'bienestar',
    password: '12345',
    port: 5432,
};

const database = new Client(options);

database.connect()
.then(client => console.log('database connected'))
.catch(error => console.error(error));

const queryDoctores = database.query('select * from doctores');
const queryServicios = database.query('select * from servicios');

Promise.all([queryDoctores, queryServicios])
.then(results => {
    const queryDoctoresResult = results[0].rows;
    const queryServiciosResult = results[1].rows;

    console.log( queryDoctoresResult);
    console.log( queryServiciosResult);

}).catch(error => console.error(error));

setTimeout( () => {
    database.end();
}, 25);