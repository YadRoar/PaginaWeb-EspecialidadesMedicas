// Mostrar el formulario cuando se hace clic en el botón "Agendar"
document.getElementById('agendar-btn').addEventListener('click', function() {
    console.log("Botón Agendar clickeado");
    document.getElementById('agendar-cita-form').style.display = 'block';
});

// Ocultar el formulario cuando se hace clic en el botón de cerrar
document.querySelector('.close').addEventListener('click', function() {
 console.log("Botón Cerrar clickeado");
 document.getElementById('agendar-cita-form').style.display = 'none';
});

// Manejar el envío del formulario
document.getElementById('agendar-form').addEventListener('submit', async function(event) {
    event.preventDefault();

    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData);

    try {
        const response = await fetch('/agendar-cita', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });

        if (response.ok) {
            alert('Cita agendada con éxito');
            // Puedes redirigir o limpiar el formulario aquí
        } else {
            alert('Hubo un problema al agendar la cita');
        }
    } catch (error) {
        console.error('Error:', error);
        alert('Error al enviar la solicitud');
    }
    // Ocultar el formulario después de enviar los datos
    document.getElementById('agendar-cita-form').style.display = 'none';
});

// Función para generar las opciones de hora disponibles







    
