//Usuarios
function cargarUsuarios() {
    fetch('/api/usuarios')
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('#tabla-usuarios tbody');
            tbody.innerHTML = ''; 
            data.forEach(usuario => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${usuario.nombre}</td>
                    <td>${usuario.apellido}</td>
                    <td>${usuario.correo}</td>
                    <td>${usuario.telefono}</td>
                    <td>${usuario.direccion}</td>
                    <td>${usuario.cedula}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editarUsuario(${usuario.cedula})">
                            <i class="bi bi-pencil-square"></i> Editar
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarUsuario(${usuario.cedula})">
                            <i class="bi bi-trash"></i> Eliminar
                        </button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        });
}

function eliminarUsuario(cedula) {
    if (confirm('¿Estás seguro de que deseas eliminar este usuario?')) {
        fetch(`/api/usuarios/${cedula}`, { method: 'DELETE' })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                cargarUsuarios(); // Recargar la tabla de usuarios después de la eliminación
            })
            .catch(error => {
                console.error('Error al eliminar el usuario:', error);
            });
    }
}

function editarUsuario(cedula) {
    window.location.href = `editarUsuario.html?cedula=${cedula}`;
}

//Doctores
function cargarDoctores() {
    fetch('/api/doctores')
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('#tabla-doctores tbody');
            tbody.innerHTML = ''; // Limpiar la tabla antes de agregar nuevos datos
            data.forEach(doctor => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${doctor.doctor}</td>
                    <td>${doctor.licencia}</td>
                    <td>${doctor.especialidad}</td>
                    <td>${doctor.codigo}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editarDoctor(${doctor.codigo})">
                            <i class="bi bi-pencil-square"></i> Editar
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarDoctor(${doctor.codigo})">
                            <i class="bi bi-trash"></i> Eliminar
                        </button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        });
}

function eliminarDoctor(codigo) {
    if (confirm('¿Estás seguro de que deseas eliminar este doctor?')) {
        fetch(`/api/doctores/${codigo}`, { method: 'DELETE' })
            .then(response => {
                if (!response.ok) throw new Error('Error en la respuesta de la red');
                return response.json();
            })
            .then(data => {
                alert(data.message);
                cargarDoctores(); // Recargar la tabla de doctores después de la eliminación
            })
            .catch(error => {
                console.error('Error al eliminar el doctor:', error);
                alert('No se pudo eliminar el doctor.');
            });
    }
}

function editarDoctor(codigo) {
    window.location.href = `editarDoctores.html?codigo=${codigo}`;
}
//Servicios
function cargarServicios() {
    fetch('/api/servicios')
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('#tabla-servicios tbody');
            tbody.innerHTML = ''; 
            data.forEach(servicio => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${servicio.especialidad}</td>
                    <td>${servicio.precio}</td>
                    <td>${servicio.requisitos}</td>
                    <td>${servicio.descripcion}</td>
                    <td>${servicio.codigo}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editarUsuario(${servicio.codigo})">
                            <i class="bi bi-pencil-square"></i> Editar
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarUsuario(${servicio.codigo})">
                            <i class="bi bi-trash"></i> Eliminar
                        </button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        });
}

function eliminarServicio(codigo) {
    if (confirm('¿Estás seguro de que deseas eliminar este servicio?')) {
        fetch(`/api/servicios/${codigo}`, { method: 'DELETE' })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                cargarServicios(); 
            });
    }
}

function editarServicio(codigo) {
    alert(`Editar servicio con ID: ${codigo}`);
}


//Citas
function cargarCitas() {
    fetch('/api/citas')
        .then(response => response.json())
        .then(data => {
            const tbody = document.querySelector('#tabla-citas tbody');
            tbody.innerHTML = ''; 
            data.forEach(cita => {
                const tr = document.createElement('tr');
                tr.innerHTML = `
                    <td>${cita.nombre}</td>
                    <td>${cita.apellidos}</td>
                    <td>${cita.cedula}</td>
                    <td>${cita.telefono}</td>
                    <td>${cita.correo}</td>
                    <td>${cita.especialidad}</td>
                    <td>${cita.hora}</td>
                    <td>${cita.fecha}</td>
                    <td>${cita.motivo}</td>
                    <td>
                        <button class="btn btn-warning btn-sm" onclick="editarCita(${cita.cedula})">
                            <i class="bi bi-pencil-square"></i> Editar
                        </button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarCita(${cita.cedula})">
                            <i class="bi bi-trash"></i> Eliminar
                        </button>
                    </td>
                `;
                tbody.appendChild(tr);
            });
        });
}

function eliminarCitas(cedula) {
    if (confirm('¿Estás seguro de que deseas eliminar esta cita?')) {
        fetch(`/api/citas/${cedula}`, { method: 'DELETE' })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                cargarCitas(); 
            });
    }
}

function editarCita(cedula) {
    alert(`Editar doctor con ID: ${cedula}`);
}


// Redirige a la página de inicio cuando se haga clic en el botón de salir
document.getElementById("logoutButton").onclick = function() {
    window.location.href = './BienestarTotal.html'; 
}
