
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const { Client } = require('pg');

const app = express();
const port = 8085;
//config db
const options = {
  user: 'postgres',
  host: 'localhost',
  database: 'bienestar',
  password: '12345',
  port: 5432,
};

const client = new Client(options);
//coneccion db
client.connect()
.then(() => console.log('Conectado a la base de datos'))
.catch(err => console.error('Error al conectar a la base de datos', err));

// Configura el directorio estático
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: false }))

app.use(express.json());

//Agendar cita
app.post('/agendar-cita', async (req, res) => {
    const { nombre, apellidos, cedula, telefono, correo, especialidad, fecha, hora, motivo } = req.body;

    try {
        const result = await client.query(
            'INSERT INTO citas (nombre, apellidos, cedula, telefono, correo, especialidad, fecha, hora, motivo) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)',
            [nombre, apellidos, cedula, telefono, correo, especialidad, fecha, hora, motivo]
        );

        res.status(201).json({ message: 'Cita agendada correctamente'  });
    } catch (error) {
        console.error('Error al agendar la cita:', error);
        res.status(500).json({ error: 'Error al agendar la cita' });
    }
});

// Ruta para obtener usuarios
app.get('/api/usuarios', async (req, res) => {
  try {
    const result = await client.query('SELECT * FROM usuarios');
    res.json(result.rows);
  } catch (err) {
    console.error('Error al obtener usuarios:', err);
    res.status(500).json({ error: 'Error al obtener usuarios' });
  }
});

// Ruta para eliminar usuario
app.delete('/api/usuarios/:cedula', async (req, res) => {
  try {
      const { cedula } = req.params;
      await client.query('DELETE FROM usuarios WHERE cedula = $1', [cedula]);
      res.json({ message: 'Usuario eliminado' });
  } catch (err) {
      console.error(err);
      res.status(500).json({ error: 'Error al eliminar el usuario' });
  }
});
// Ruta para obtener un usuario por cédula
app.get('/api/usuarios/:cedula', async (req, res) => {
  try {
      const { cedula } = req.params;

      // Validación básica para asegurar que la cédula no sea null
      if (!cedula) {
          return res.status(400).json({ error: 'La cédula es requerida' });
      }

      const result = await client.query('SELECT * FROM usuarios WHERE cedula = $1', [cedula]);

      if (result.rows.length === 0) {
          return res.status(404).json({ error: 'Usuario no encontrado' });
      }

      res.json(result.rows[0]);
  } catch (err) {
      console.error('Error al obtener usuario:', err);
      res.status(500).json({ error: 'Error al obtener usuario' });
  }
});

// Ruta para actualizar un usuario
app.put('/api/usuarios/:cedula', async (req, res) => {
  const { cedula } = req.params;
  const { nombre, apellido, correo, telefono, direccion } = req.body;

  // Validación de entrada
  if (!cedula || !nombre || !apellido || !correo || !telefono || !direccion) {
      return res.status(400).json({ error: 'Todos los campos son requeridos' });
  }

  try {
      // Debugging: verifica si los datos están siendo recibidos correctamente
      console.log('Cédula:', cedula);
      console.log('Datos recibidos:', req.body);

      await client.query(
          'UPDATE usuarios SET nombre = $1, apellido = $2, correo = $3, telefono = $4, direccion = $5 WHERE cedula = $6',
          [nombre, apellido, correo, telefono, direccion, cedula]
      );
      res.json({ message: 'Usuario actualizado correctamente' });
  } catch (err) {
      console.error('Error al actualizar el usuario:', err);
      res.status(500).json({ error: 'Error al actualizar el usuario' });
  }
});


// Ruta para obtener doctores
app.get('/api/doctores', async (req, res) => {
  try {
    const result = await client.query('SELECT * FROM doctores');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener doctores' });
  }
});

// Ruta para eliminar doctor
app.delete('/api/doctores/:codigo', async (req, res) => {
  try {
    const { codigo } = req.params;
    await client.query('DELETE FROM doctores WHERE codigo = $1', [codigo]);
    res.json({ message: 'Doctor eliminado' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al eliminar el doctor' });
  }
});

// Ruta para obtener citas
app.get('/api/citas', async (req, res) => {
  try {
    const result = await client.query('SELECT * FROM citas');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener citas' });
  }
});
// Ruta para eliminar citas
app.delete('/api/citas/:cedula', async (req, res) => {
  try {
    const { cedula } = req.params;
    await client.query('DELETE FROM citas WHERE cedula = $1', [cedula]);
    res.json({ message: 'Cita eliminada' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al eliminar la cita' });
  }
});

// Ruta para obtener servicios
app.get('/api/servicios', async (req, res) => {
  try {
    const result = await client.query('SELECT * FROM servicios');
    res.json(result.rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al obtener servicios' });
  }
});

// Ruta para eliminar servicios
app.delete('/api/servicios/:codigo', async (req, res) => {
  try {
    const { codigo } = req.params;
    await client.query('DELETE FROM servicios WHERE codigo = $1', [codigo]);
    res.json({ message: 'Servicio eliminado' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Error al eliminar el servicio' });
  }
});

// Ruta para manejar todas las demás solicitudes y enviar el archivo BienestarTotal.html
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'BienestarTotal.html'));
});

app.listen(port, () => {
  console.log(`Servidor corriendo en http://localhost:${port}`);
});

